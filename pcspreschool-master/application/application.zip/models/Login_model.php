<?php

class Login_model extends CI_Model{



	function loginParent($parentData){
	
		$q=$this->db->query("SELECT
			ps.`id` parent_id,
			ps.`email`,
			ps.`name`,
			ps.`picture`,
			ps.`parent_type`,
			ps.`password`,
			ps.`preschool_id`,
			ps.`phone_number`
			FROM
			  `parent` ps
			WHERE (ps.email=?
			OR ps.phone_number=?)
			",array($parentData['loginUniq'],$parentData['loginUniq']));
		
		$retParentData=$q->result_array()[0];
		if((password_verify($parentData['password'],$retParentData['password']))){
			unset($retParentData['password']);
			return $retParentData;
		}
		else{
			return false;
			
		}

	}


	function loginStaff($staffData){
		$q=$this->db->query("
				   SELECT
				  `id` staff_id,
				   CONCAT(`first_name`,' ',`last_name`) staff_name,
				  `email`,
				  `phone_number`,
				  `preschool_id`,
				  `dob`,
				  `gender`,
				  `picture`,
				  `password`,
				  `class_id`,
				  `start_date`,
				  `schedule_day`,
				  `country`,
				  `state`,
				  `city`,
				  `zipcode`,
				  `address`,
				  `certification_names`
				FROM
				  `staff`
				  WHERE(
				  email=? OR
				  phone_number = ?)
				",array($staffData['loginUniq'],$staffData['loginUniq']));
		$retStaffData=$q->result_array()[0];
		// return $retStaffData;
		if((password_verify($staffData['password'],$retStaffData['password']))){
			unset($retStaffData['password']);
			return $retStaffData;
		}
		else{
			return false;
			
		}

	}
	
	function getHoliday($preschoolId){ 
		$q=$this->db->query("SELECT
					  pcal.`calendar_date`,
					  phol.`reason`
					FROM
					  preschool_calender pcal
					LEFT JOIN holiday phol ON(
					phol.`holiday_date`=pcal.`calendar_date`
					)
					WHERE phol.`preschool_id`=?");
	}	
	
	function getFeeStatus($preschoolId,$parentId){ 
		$q=$this->db->query("SELECT pfees.*
				FROM
				  parent_fees pfees
				  LEFT JOIN child cs
					ON (cs.`fees_status_id` = pfees.`id`)
				  LEFT JOIN parent ps
					ON ((ps.id MEMBER OF (cs.parents_id)) = 1)
				WHERE ps.preschool_id = ?
				  AND ps.id = ?",array($preschoolId,$parentId));
		return $q->result_array();
	}
	
	function getChildNotes($preschoolId,$parentId,$date=null){ 
		if($date==null){
			$q=$this->db->query("SELECT
				  cs.first_name,
				  cnot.*
				FROM
				  child_notes cnot
				  LEFT JOIN child cs
					ON (cs.id = cnot.`child_id`)
				  LEFT JOIN parent ps
					ON ((ps.id MEMBER OF (cs.parents_id)) = 1)
				WHERE ps.preschool_id = ?
				  AND ps.id = ?
				  AND (cnot.`type` <> 'ptm' AND cnot.`type` <> 'notice')",array($preschoolId,$parentId));
			return $q->result_array();
		}else{
			$q=$this->db->query("SELECT
			  cs.first_name,
			  cnot.*
			FROM
			  child_notes cnot
			  LEFT JOIN child cs
				ON (cs.id = cnot.`child_id`)
			  LEFT JOIN parent ps
				ON ((ps.id MEMBER OF (cs.parents_id)) = 1)
			WHERE ps.preschool_id = ?
			  AND ps.id = ?
			  AND DATE(cnot.`create_timestamp`)=?
			  AND (cnot.`type` <> 'ptm' AND cnot.`type` <> 'notice')",array($preschoolId,$parentId,$date));
		return $q->result_array();

		}
	
	}

	function confirmPassword($confPassword,$userTable,$id){
		$q=$this->db->query(
		"Select password from {$userTable} where id=?",array($id)
		);
		$hashPassword=$q->result_array()[0]["password"];
		if((password_verify($confPassword,$hashPassword))){
			return true;
		}
		return false;
	}


	function setParentPassword($prechoolId,$parentId,$password){
		 $newPassword=password_hash($password, PASSWORD_BCRYPT);
		 
		 $this->db->where(array("id"=>$parentId));
		 $this->db->update("parent",array("password"=>$newPassword));
		
		
	}


}
?>