<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
		 header("Content-type:application/json");
		$this->load->model("Parent_model","mypm");
		$this->load->model("Child_model","mycm");
		$this->load->model("Staff_model","mysm");
		$this->load->model("Login_model","mylm");
		}

    public function parentData($type=null,$preschoolId=null)
    {
    // $postedData=json_decode(file_get_contents("php://input"));
		if($type=="login"){
			$postedData["loginUniq"]=$this->input->post("loginUniq");
			$postedData["password"]=$this->input->post("password");
			if(empty(trim($postedData["password"])) or empty(trim($postedData["loginUniq"]))){
			echo json_encode(array("result"=>false,"reason"=>"Insufficient parameters password"));
			exit;
			}
			$data=$this->mylm->loginParent($postedData);
			if($data){
			$data["childData"]=$this->mypm->getParentChild($data["preschool_id"],$data["parent_id"]);
            }
		}
		// if($type="all"){
			// $data=$this->mypm->getParentData($preschoolId);
		// }
		 if($data){
		    echo json_encode(array($data));
            exit;

		 }
		 else{
		     echo json_encode(array("result"=>false,"reason"=>"Invalid credentials passed"));


		 }
	
	}
	 public function attendance()
    {   
		$postedData["preschool_id"]=$this->input->post("preschoolId");
		$postedData["childId"]=$this->input->post("childId");
		$postedData["month"]=$this->input->post("month");
		$postedData["year"]=$this->input->post("year");
		// $holiday=null;
		$date = new DateTime("now");
		$dcount=null;
		$data=array();
		if($postedData["month"]==$date->format("m")){
			
			
			$data["holiday"]=$this->mysm->getHolidaybyMonth($postedData["preschool_id"],$postedData["month"],$postedData["year"],$date->format("Y-m-d"));
			$dcount=$date->format("d");
			
		}else{
			$dcount=cal_days_in_month(CAL_GREGORIAN,$postedData["month"],$postedData["year"]);
			$data["holiday"]=$this->mysm->getHolidaybyMonth($postedData["preschool_id"],$postedData["month"],$postedData["year"]);
		}
		$data["present"]=$this->mycm->getChildAttendancebyMonth($postedData["childId"],PRESENT,$postedData["month"],$postedData["year"]);
		
		$data["absent"]=$this->mycm->getChildAttendancebyMonth($postedData["childId"],ABSENT,$postedData["month"],$postedData["year"]);
		
		$data["leave"]=$this->mycm->getChildAttendancebyMonth($postedData["childId"],LEAVE,$postedData["month"],$postedData["year"]);

			
		
		
			echo json_encode($data);


		
		
	}
	
	public function notes(){
		$preschoolId=$this->input->post("preschoolId");
		$childId=$this->input->post("childId");
		if($preschoolId==null){
		    
		echo json_encode(array("result"=>"failure","reason"=>"Preschool ID not provided"));
		exit;
		}
		if($childId==null){
		    
		echo json_encode(array("result"=>"failure","reason"=>"Child ID not provided"));
		exit;
		    
		}
		$data=$this->mycm->getChildNotes(1,1);
		foreach($data as $key=>$indiData){
		$data[$key]["time"]=date("h:i:s a",strtotime($indiData["time"]));
		}
		echo json_encode($data);
		
		
		
		
	}
	
	public function announcements(){
		$preschoolId=$this->input->post("preschoolId");
		if($preschoolId==null){
		    
		echo json_encode(array("result"=>"failure","reason"=>"Preschool ID not provided"));
		exit;
		}
		
		$data=$this->mysm->getPreschoolAnnouncements($preschoolId);
		if($data==null or empty($data)){
		echo json_encode(array("result"=>"failure","reason"=>"Announcements for given Preschool ID does not exist"));
		exit;
			
		}
		foreach($data as $key=>$indiData){
		$data[$key]["time"]=date("h:i:s a",strtotime($indiData["time"]));
		}	
		echo json_encode($data);

	}
	
	public function activity(){
		$preschoolId=$this->input->post("preschoolId");
		$month=$this->input->post("month");
		$year=$this->input->post("year");
		if($preschoolId==null || $month==null || $year==null ){
		    
		echo json_encode(array("result"=>"failure","reason"=>"Parameter is missing"));
		exit;
		}
				
		$data=$this->mysm->getPreschoolActivityByMonth($preschoolId,$month,$year);
		foreach($data as $key=>$activity){
		$data[$key]["class_name"]=($activity["class_id"]==null || strlen($activity["class_id"])<3)?"All":$this->mysm->getClassName(json_decode($activity["class_id"]));
		$data[$key]["class_id"]=json_decode($activity["class_id"]);
		}
		if($data==null or empty($data)){
		echo json_encode(array("result"=>"failure","reason"=>"Activities for given Preschool ID does not exist"));
		exit;
			
		}
		echo json_encode($data);	
		
	}
	public function mealplan(){
		$preschoolId=$this->input->post("preschoolId");

		if($preschoolId==null){
		    
		echo json_encode(array("result"=>"failure","reason"=>"Parameter is missing"));
		exit;
		}
		
		$data=$this->mysm->getMealPlan($preschoolId);
		foreach($data as $key=>$meal){
			$data[$key]["meal_weekday"]=num_to_weekday($meal["meal_weekday"]);
			$data[$key]["meal"]=json_decode($meal["meal"]);
		}
		
		if($data==null or empty($data)){
		echo json_encode(array("result"=>"failure","reason"=>"Meal Plan for given Preschool ID does not exist"));
		exit;
			
		}
		echo json_encode($data);
	}

	public function gallery(){
		$preschoolId=$this->input->post("preschoolId");

		if($preschoolId==null){
		    
		echo json_encode(array("result"=>"failure","reason"=>"Parameter is missing"));
		exit;
		}
		
		$data=$this->mysm->getGalleryData($preschoolId);

		if($data==null or empty($data)){
		echo json_encode(array("result"=>"failure","reason"=>"Gallery Data for given Preschool ID does not exist"));
		exit;
			
		}
		echo json_encode($data);
	}



}