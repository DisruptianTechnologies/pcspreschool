<?php



function sellipses($string,$limit){
	if(strlen($string)>=$limit){
	return substr($string,0,$limit-3).'...';
	}
	else{
		return $string;
	}
	
}

function weekday_num_to_text($array,$arrkey){
	$arr=$array;
	$weekdayTemp=array("monday","tuesday","wednesday","thursday","friday","saturday","sunday");
		foreach($array as $key=>$val){
			$arr[$key][$arrkey]=$weekdayTemp[$val[$arrkey]];
				// echo "<pre>";
				// print_r($arr[$key][$arrkey]);
				// echo "</pre>";

		}
	
	return $arr;
	
}

function num_to_weekday($weekday){
	if(is_array($weekday)){
		$temp=array();
		foreach($weekday as $day){
			$temp[]=num_to_weekday($day);
		}
			return $temp;
	}
	else{
	return array("Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday")[$weekday];
	}
}

function json_to_str($json){
	$a=json_decode($json);
	if(is_array($a)){
	return implode(',',array_map('ucfirst',json_decode($a)));
	}
	else{
	return $json;
	}
}

function check_today_attendance($lastattendancedate,$status){
	if($lastattendancedate==(new DateTime("now"))->format("Y-m-d")){
		if($status==1){	
			return "Present";
		}elseif($status==0){
			return "Absent";
		}elseif($status==2){
			return "Leave";
		}
		
		
		
		
	}
	else{
		
		return "Undefined";
	}

}

function attendance_status($status){
	
	if(strlen($status)>0)
	return array("Absent","Present","Leave")[$status];
	else{
		return "None";
	}
}

function uploadPicture($pic,$path,$nameConvention,$redirectLink){

		$ci =& get_instance();
		$config=array();
		$config['upload_path']          = $path;
		$config['allowed_types']        = 'jpg|png|webp';
		$config['max_size']             = 2048;
		$config['max_width']            = 1024;
		$config['max_height']           = 1024;
		$config['file_name']			=$nameConvention."_".rand(0,999)."_".time();

		$ci->upload->initialize($config);	
		
		if ( !$ci->upload->do_upload($pic))
		{
				$ci->session->set_flashdata('error',$ci->upload->display_errors());
			
				redirect($redirectLink);
		}				
		else{
				return $path.$ci->upload->data('file_name');
			
		}

	
}

function uploadToGallery($pic,$nameConvention,$redirectLink){

		$ci =& get_instance();
		$config=array();
		$path="./px-includes/preschool/img/";
		$config['upload_path']          = $path;
		$config['allowed_types']        = 'jpg|png|webp';
		$config['max_size']             = 6048;
		$config['file_name']			=$nameConvention."_".rand(0,999)."_".time();

		$ci->upload->initialize($config);	
		
		if ( !$ci->upload->do_upload($pic))
		{
				$ci->session->set_flashdata('error',$ci->upload->display_errors());
			
				redirect($redirectLink);
		}				
		else{
				return $path.$ci->upload->data('file_name');
			
		}

	
}

function uploadAttachment($file,$fileType,$redirectLink){
		$ci =& get_instance();
		if($fileType=="pdf"){
			$path="./px-includes/preschool/pdf/";
		}
		else{
			$path="./px-includes/preschool/img/";
		}

		$config=array();
		$config['upload_path']          = $path;
		$config['allowed_types']        = 'jpg|pdf|png|webp';
		$config['max_size']             = 4048;

		$config['file_name']			=rand(0,999)."_".time();

		$ci->upload->initialize($config);	
		
		if ( !$ci->upload->do_upload($file))
		{
				$ci->session->set_flashdata('error',$ci->upload->display_errors());
			
				redirect($redirectLink);
		}				
		else{
				return $path.$ci->upload->data('file_name');
			
		}

}

function num_to_seen($num){
	return array("Unseen","Seen")[$num];

}
	


?>