    <footer class="footer footer-static footer-light">
      <p class="clearfix mb-0"><span class="float-left d-inline-block">2020 &copy; Disruptian Technologies</span>
        <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="bx bx-up-arrow-alt"></i></button>
      </p>
    </footer>
		<script>
		var app = angular.module('myApp', []);
		app.controller('header_controller', function($scope) {
		  $scope.noti_head =<?=json_encode($notif_header)?>;
		  $scope.sos_head=<?=json_encode($sos_header)?>;
			});

	</script>